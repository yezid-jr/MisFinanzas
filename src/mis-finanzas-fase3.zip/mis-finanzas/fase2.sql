-- =====================================================================
-- FASE 2 · cambios en la base de datos
-- Ejecutar en Supabase → SQL Editor (una sola vez)
-- =====================================================================

-- 1) Cobros recurrentes: fecha del último cobro registrado
alter table public.recurring_charges
  add column if not exists last_posted_on date;

-- 2) Conciliar una caja con el saldo real de Nu:
--    si el saldo real es mayor -> rendimiento ('yield'); si es menor -> ajuste
create or replace function public.reconcile_pocket(
  p_pocket uuid, p_real numeric, p_date date default current_date
) returns numeric language plpgsql as $$
declare
  v_balance numeric;
  v_diff    numeric;
begin
  if p_real < 0 then raise exception 'El saldo real no puede ser negativo'; end if;
  select coalesce(sum(amount), 0) into v_balance
    from public.movements where pocket_id = p_pocket;
  v_diff := round(p_real - v_balance, 2);
  if v_diff = 0 then return 0; end if;
  insert into public.movements (occurred_on, kind, pocket_id, amount, note)
  values (p_date, case when v_diff > 0 then 'yield' else 'adjustment' end,
          p_pocket, v_diff, 'Conciliación con el saldo real');
  return v_diff;
end $$;

-- 3) Totales por día (para la gráfica de evolución)
create or replace view public.daily_totals with (security_invoker = true) as
select occurred_on, sum(amount) as net
from public.movements
group by occurred_on;

-- 4) Ritmo de ahorro por caja desde una fecha (para proyectar metas)
create or replace function public.pocket_net_since(p_since date)
returns table (pocket_id uuid, net numeric)
language sql stable as $$
  select m.pocket_id, coalesce(sum(m.amount), 0)
  from public.movements m
  where m.occurred_on >= p_since and m.kind <> 'opening'
  group by m.pocket_id
$$;

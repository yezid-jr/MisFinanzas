-- =====================================================================
-- FASE 3 · notificaciones push
-- Ejecutar en Supabase → SQL Editor (una sola vez)
-- =====================================================================
create table public.push_subscriptions (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  endpoint    text not null unique,
  p256dh      text not null,
  auth        text not null,
  user_agent  text,
  created_at  timestamptz not null default now()
);

alter table public.push_subscriptions enable row level security;

create policy "own rows" on public.push_subscriptions
  for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Si ya creaste la política "solo mi correo" en las demás tablas, agrégala aquí también
-- (cambia TU_CORREO@gmail.com):
-- create policy "solo mi correo" on public.push_subscriptions as restrictive
--   for all to authenticated
--   using ((auth.jwt() ->> 'email') = 'TU_CORREO@gmail.com');

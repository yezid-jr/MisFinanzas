import { createClient } from '@/lib/supabase/server'
import { loadUpcoming } from '@/lib/data'
import { cop } from '@/lib/format'
import { fundingByPocket } from '@/lib/upcoming'
import UpcomingList from '@/components/upcoming-list'
import { DeleteRecurringButton, RecurringForm } from '@/components/cobros-actions'
import type { Category, PocketLite, RecurringCharge } from '@/lib/types'

export default async function CobrosPage() {
  const supabase = await createClient()
  const [upcoming, recRes, pocketsRes, catsRes] = await Promise.all([
    loadUpcoming(),
    supabase.from('recurring_charges').select('*').eq('is_active', true).order('day_of_month'),
    supabase.from('pocket_balances').select('pocket_id,name,emoji,balance').order('priority'),
    supabase.from('categories').select('id,name,emoji,default_pocket_id').order('name'),
  ])

  const recurring = (recRes.data ?? []) as RecurringCharge[]
  const pockets = (pocketsRes.data ?? []) as PocketLite[]
  const categories = (catsRes.data ?? []) as Category[]
  const warnings = fundingByPocket(upcoming.items, 30)
  const monthlyFixed = recurring.reduce((s, r) => s + Number(r.amount), 0)

  return (
    <main className="space-y-6">
      <h1 className="text-2xl font-bold">Cobros y alertas</h1>

      {warnings.length > 0 && (
        <section className="space-y-2">
          {warnings.map((w) => (
            <p key={w.name} className="rounded-xl bg-amber-50 p-3 text-sm text-amber-800">
              ⚠️ En los próximos 30 días <b>{w.name}</b> necesita {cop(w.needed)} y tiene {cop(w.balance)}. Faltan{' '}
              <b>{cop(w.short)}</b>.
            </p>
          ))}
        </section>
      )}

      <section className="space-y-3">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Lo que viene</h2>
        <UpcomingList items={upcoming.items.filter((i) => i.days <= 45)} />
      </section>

      <section className="space-y-3">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
          Mis cobros fijos · {cop(monthlyFixed)} al mes
        </h2>
        <ul className="space-y-2">
          {recurring.map((r) => (
            <li key={r.id} className="flex items-center justify-between rounded-2xl bg-white p-4 shadow-sm">
              <div>
                <p className="font-medium">{r.name}</p>
                <p className="text-xs text-slate-500">Cada día {r.day_of_month}</p>
              </div>
              <div className="text-right">
                <p className="font-semibold">{cop(r.amount)}</p>
                <DeleteRecurringButton id={r.id} name={r.name} />
              </div>
            </li>
          ))}
        </ul>
      </section>

      <RecurringForm pockets={pockets} categories={categories} />
    </main>
  )
}

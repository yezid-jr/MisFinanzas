import { createClient } from '@/lib/supabase/server'
import type { PocketBalance } from '@/lib/types'
import ReconcileForm from './reconcile-form'

export default async function ReconcilePage() {
  const supabase = await createClient()
  const { data } = await supabase.from('pocket_balances').select('*').order('priority')

  return (
    <main className="space-y-4">
      <h1 className="text-2xl font-bold">Conciliar con Nu y Bancolombia</h1>
      <p className="text-sm text-slate-500">
        Escribe el saldo real que ves hoy en cada cajita. Si es mayor al de la app, la diferencia se registra como
        rendimiento; si es menor, como ajuste.
      </p>
      <ReconcileForm pockets={(data ?? []) as PocketBalance[]} />
    </main>
  )
}

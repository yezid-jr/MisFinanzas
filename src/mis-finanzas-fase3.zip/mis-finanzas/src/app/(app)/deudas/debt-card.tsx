'use client'

import { useState, useTransition } from 'react'
import { addDebtEntry, payDebt, syncDebtBalance } from '@/lib/actions'
import { cop, cop2, parseMoney, pct, todayBogota } from '@/lib/format'
import { shortDate } from '@/lib/dates'
import { monthlyRate } from '@/lib/finance'
import type { Debt, DebtKind, Installment, PocketLite } from '@/lib/types'
import { Feedback, Field, SubmitButton, inputClass } from '@/components/ui'

const KIND_LABEL: Record<DebtKind, string> = {
  student_loan: '🎓 Crédito educativo',
  credit_card: '💳 Tarjeta de crédito',
  bnpl: '🛍️ Compra a cuotas',
  person: '🤝 Persona',
  other: '📄 Otra',
}

type Mode = 'pay' | 'charge' | 'sync' | null

export default function DebtCard({
  debt,
  pockets,
  installments,
  yieldEa,
}: {
  debt: Debt & { balance: number }
  pockets: PocketLite[]
  installments: Installment[]
  yieldEa: number
}) {
  const next = installments[0] ?? null
  const [mode, setMode] = useState<Mode>(null)
  const [amountText, setAmountText] = useState(next ? String(Math.round(Number(next.amount))) : '')
  const [pocketId, setPocketId] = useState(debt.default_pocket_id ?? '')
  const [useInstallment, setUseInstallment] = useState(!!next)
  const [chargeKind, setChargeKind] = useState<'charge' | 'interest' | 'fee'>('charge')
  const [date, setDate] = useState(todayBogota())
  const [note, setNote] = useState('')
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null)
  const [pending, startTransition] = useTransition()

  const rate = debt.rate_ea ? Number(debt.rate_ea) : null
  const monthlyInterest = rate ? debt.balance * monthlyRate(rate) : 0
  const usage = debt.credit_limit ? (debt.balance / Number(debt.credit_limit)) * 100 : null
  const amount = parseMoney(amountText)
  const pocket = pockets.find((p) => p.pocket_id === pocketId)

  function open(m: Mode) {
    setResult(null)
    setMode(mode === m ? null : m)
    if (m === 'sync') setAmountText(debt.balance.toFixed(2).replace('.', ','))
    if (m === 'pay') setAmountText(next ? String(Math.round(Number(next.amount))) : '')
    if (m === 'charge') setAmountText('')
  }

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    startTransition(async () => {
      let res
      if (mode === 'pay') {
        res = await payDebt({
          debtId: debt.id,
          pocketId,
          amount,
          date,
          installmentId: useInstallment && next ? next.id : null,
          note,
        })
      } else if (mode === 'charge') {
        res = await addDebtEntry({ debtId: debt.id, kind: chargeKind, amount, date, note })
      } else {
        res = await syncDebtBalance({ debtId: debt.id, realBalance: amount, date })
      }
      if (res.ok) {
        setResult({ ok: true, message: 'Listo ✅' })
        setMode(null)
        setNote('')
      } else {
        setResult({ ok: false, message: res.error })
      }
    })
  }

  return (
    <div className="space-y-3 rounded-2xl bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="font-semibold">{debt.name}</p>
          <p className="text-xs text-slate-400">{KIND_LABEL[debt.kind]}</p>
        </div>
        <p className="text-xl font-bold text-rose-600">{cop2(debt.balance)}</p>
      </div>

      {usage !== null && (
        <div>
          <div className="h-2 overflow-hidden rounded-full bg-slate-100">
            <div
              className={`h-full rounded-full ${usage > 70 ? 'bg-rose-500' : 'bg-amber-400'}`}
              style={{ width: `${Math.min(100, usage)}%` }}
            />
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Usas {pct(usage, 0)} de tu cupo de {cop(debt.credit_limit)}
          </p>
        </div>
      )}

      {rate !== null && (
        <div className="flex flex-wrap gap-2 text-xs">
          <span className="rounded-full bg-slate-100 px-2 py-1">{pct(rate, 2)} E.A.</span>
          <span className="rounded-full bg-slate-100 px-2 py-1">≈ {cop(monthlyInterest)} de interés al mes</span>
          <span
            className={`rounded-full px-2 py-1 ${
              rate > yieldEa ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
            }`}
          >
            {rate > yieldEa ? 'Cuesta más' : 'Cuesta menos'} que el {pct(yieldEa, 2)} que rinden tus cajas
          </span>
        </div>
      )}

      {installments.length > 0 && (
        <div className="rounded-lg bg-slate-50 p-3 text-sm">
          <p className="mb-1 text-xs font-semibold text-slate-500">Cuotas pendientes</p>
          <ul className="space-y-0.5">
            {installments.map((i) => (
              <li key={i.id} className="flex justify-between">
                <span>{shortDate(i.due_on)}</span>
                <span className="font-medium">{cop2(i.amount)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {debt.due_day && (
        <p className="text-xs text-slate-500">
          Fecha límite de pago: día {debt.due_day}
          {debt.cutoff_day ? ` · corte: día ${debt.cutoff_day}` : ''}
        </p>
      )}
      {debt.notes && <p className="text-xs text-slate-400">{debt.notes}</p>}

      <div className="grid grid-cols-3 gap-2 text-sm">
        {(
          [
            ['pay', 'Pagar'],
            ['charge', 'Cargo'],
            ['sync', 'Saldo real'],
          ] as const
        ).map(([m, label]) => (
          <button
            key={m}
            type="button"
            onClick={() => open(m)}
            className={`rounded-xl border px-2 py-2 ${
              mode === m ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-300'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {mode && (
        <form onSubmit={onSubmit} className="space-y-3 border-t border-slate-100 pt-3">
          {mode === 'charge' && (
            <Field label="Tipo de cargo">
              <select
                className={inputClass}
                value={chargeKind}
                onChange={(e) => setChargeKind(e.target.value as 'charge' | 'interest' | 'fee')}
              >
                <option value="charge">Compra o cargo</option>
                <option value="interest">Interés</option>
                <option value="fee">Cuota de manejo / comisión</option>
              </select>
            </Field>
          )}

          <Field label={mode === 'sync' ? 'Saldo real según la plataforma' : 'Monto'}>
            <input
              inputMode="decimal"
              className={inputClass}
              value={amountText}
              onChange={(e) => setAmountText(e.target.value)}
              placeholder="0"
            />
          </Field>

          {mode === 'pay' && (
            <>
              <Field label="¿De qué caja sale el pago?">
                <select className={inputClass} value={pocketId} onChange={(e) => setPocketId(e.target.value)} required>
                  <option value="">Elige una caja…</option>
                  {pockets.map((p) => (
                    <option key={p.pocket_id} value={p.pocket_id}>
                      {p.emoji} {p.name} · {cop(p.balance)}
                    </option>
                  ))}
                </select>
              </Field>
              {pocket && amount > Number(pocket.balance) && (
                <p className="rounded-lg bg-amber-50 p-2 text-xs text-amber-800">
                  {pocket.name} solo tiene {cop(pocket.balance)}. Mueve plata primero desde otra caja.
                </p>
              )}
              {next && (
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={useInstallment} onChange={(e) => setUseInstallment(e.target.checked)} />
                  Este pago es la cuota del {shortDate(next.due_on)}
                </label>
              )}
            </>
          )}

          {mode === 'sync' && (
            <p className="text-xs text-slate-500">
              Diferencia con la app: {cop2(amount - debt.balance)}. Se registra como ajuste.
            </p>
          )}

          <Field label="Fecha">
            <input type="date" className={inputClass} value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          {mode !== 'sync' && (
            <Field label="Nota (opcional)">
              <input className={inputClass} value={note} onChange={(e) => setNote(e.target.value)} />
            </Field>
          )}

          <Feedback result={result} />
          <SubmitButton pending={pending}>
            {mode === 'pay' ? 'Registrar pago' : mode === 'charge' ? 'Registrar cargo' : 'Actualizar saldo'}
          </SubmitButton>
        </form>
      )}

      {!mode && <Feedback result={result} />}
    </div>
  )
}

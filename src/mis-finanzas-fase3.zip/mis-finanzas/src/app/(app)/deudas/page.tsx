import { createClient } from '@/lib/supabase/server'
import { cop } from '@/lib/format'
import { monthlyRate } from '@/lib/finance'
import type { Debt, DebtBalance, Installment, PocketLite } from '@/lib/types'
import DebtCard from './debt-card'

export default async function DebtsPage() {
  const supabase = await createClient()
  const [debtsRes, balRes, instRes, pocketsRes, settingsRes] = await Promise.all([
    supabase.from('debts').select('*').eq('is_active', true).order('name'),
    supabase.from('debt_balances').select('debt_id,balance'),
    supabase.from('debt_installments').select('*').is('paid_at', null).order('due_on'),
    supabase.from('pocket_balances').select('pocket_id,name,emoji,balance').order('priority'),
    supabase.from('settings').select('nu_rate_ea').maybeSingle(),
  ])

  const balances = new Map(((balRes.data ?? []) as DebtBalance[]).map((b) => [b.debt_id, Number(b.balance)]))
  const installments = (instRes.data ?? []) as Installment[]
  const pockets = (pocketsRes.data ?? []) as PocketLite[]
  const yieldEa = Number(settingsRes.data?.nu_rate_ea ?? 9.35)

  const debts = ((debtsRes.data ?? []) as Debt[]).map((d) => ({ ...d, balance: balances.get(d.id) ?? 0 }))
  const total = debts.reduce((s, d) => s + d.balance, 0)
  const monthlyInterest = debts.reduce(
    (s, d) => s + (d.rate_ea ? d.balance * monthlyRate(Number(d.rate_ea)) : 0),
    0
  )

  return (
    <main className="space-y-4">
      <h1 className="text-2xl font-bold">Deudas</h1>

      <section className="grid grid-cols-2 gap-2 text-center">
        <div className="rounded-xl bg-white p-3 shadow-sm">
          <p className="text-lg font-semibold text-rose-600">{cop(total)}</p>
          <p className="text-[11px] text-slate-500">Deuda total</p>
        </div>
        <div className="rounded-xl bg-white p-3 shadow-sm">
          <p className="text-lg font-semibold text-orange-600">≈ {cop(monthlyInterest)}</p>
          <p className="text-[11px] text-slate-500">Interés estimado al mes</p>
        </div>
      </section>

      {debts.length === 0 && (
        <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-800">Aún no hay deudas registradas.</p>
      )}

      {debts.map((d) => (
        <DebtCard
          key={d.id}
          debt={d}
          pockets={pockets}
          installments={installments.filter((i) => i.debt_id === d.id)}
          yieldEa={yieldEa}
        />
      ))}
    </main>
  )
}

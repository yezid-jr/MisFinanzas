'use client'

import { useState, useTransition } from 'react'
import { deleteMovementGroup } from '@/lib/actions'

export default function DeleteGroupButton({ groupId }: { groupId: string }) {
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  return (
    <div>
      <button
        disabled={pending}
        onClick={() => {
          if (!confirm('¿Borrar este movimiento completo? Los saldos se recalcularán.')) return
          startTransition(async () => {
            const res = await deleteMovementGroup(groupId)
            setError(res.ok ? null : res.error)
          })
        }}
        className="text-xs text-slate-400 underline disabled:opacity-50"
      >
        {pending ? 'Borrando…' : 'Borrar'}
      </button>
      {error && <p className="text-xs text-red-600">{error}</p>}
    </div>
  )
}

import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { shortDate } from '@/lib/dates'
import { cop2 } from '@/lib/format'
import DeleteGroupButton from './delete-button'

type Row = {
  id: string
  group_id: string
  occurred_on: string
  kind: string
  amount: number
  note: string | null
  income_source: string | null
  pocket: { name: string; emoji: string | null } | null
  category: { name: string; emoji: string | null } | null
}

const FILTERS: { key: string; label: string; kinds: string[] | null }[] = [
  { key: 'todo', label: 'Todo', kinds: null },
  { key: 'ingresos', label: 'Ingresos', kinds: ['income'] },
  { key: 'gastos', label: 'Gastos', kinds: ['expense'] },
  { key: 'mover', label: 'Movimientos', kinds: ['transfer_in', 'transfer_out'] },
  { key: 'deudas', label: 'Deudas', kinds: ['debt_payment'] },
  { key: 'otros', label: 'Otros', kinds: ['yield', 'adjustment', 'opening'] },
]

const SOURCE: Record<string, string> = { work: 'Trabajo', tattoo: 'Tatuaje', other: 'Otro' }

function describe(rows: Row[]) {
  const first = rows[0]
  const total = rows.reduce((s, r) => s + Number(r.amount), 0)
  switch (first.kind) {
    case 'income':
      return { icon: '💵', title: `Ingreso · ${SOURCE[first.income_source ?? 'other']}`, amount: total, tone: 'text-emerald-600' }
    case 'expense':
      return {
        icon: first.category?.emoji ?? '🧾',
        title: first.category?.name ?? 'Gasto',
        amount: total,
        tone: 'text-rose-600',
      }
    case 'transfer_in':
    case 'transfer_out': {
      const from = rows.find((r) => r.kind === 'transfer_out')?.pocket?.name
      const to = rows.find((r) => r.kind === 'transfer_in')?.pocket?.name
      return { icon: '🔁', title: `${from ?? '?'} → ${to ?? '?'}`, amount: Math.abs(Number(rows.find((r) => r.kind === 'transfer_in')?.amount ?? 0)), tone: 'text-slate-600' }
    }
    case 'debt_payment':
      return { icon: '💳', title: 'Pago de deuda', amount: total, tone: 'text-orange-600' }
    case 'yield':
      return { icon: '📈', title: 'Rendimiento', amount: total, tone: 'text-sky-600' }
    case 'opening':
      return { icon: '🏁', title: 'Saldo inicial', amount: total, tone: 'text-slate-600' }
    default:
      return { icon: '⚖️', title: 'Ajuste', amount: total, tone: 'text-slate-600' }
  }
}

export default async function HistoryPage({
  searchParams,
}: {
  searchParams: Promise<{ tipo?: string }>
}) {
  const { tipo } = await searchParams
  const filter = FILTERS.find((f) => f.key === tipo) ?? FILTERS[0]

  const supabase = await createClient()
  let query = supabase
    .from('movements')
    .select(
      'id,group_id,occurred_on,kind,amount,note,income_source,pocket:pockets(name,emoji),category:categories(name,emoji)'
    )
    .order('occurred_on', { ascending: false })
    .order('created_at', { ascending: false })
    .limit(200)
  if (filter.kinds) query = query.in('kind', filter.kinds)

  const { data } = await query
  const rows = (data ?? []) as unknown as Row[]

  // Agrupa por movimiento (una transferencia son 2 filas, un ingreso repartido son varias)
  const groups = new Map<string, Row[]>()
  for (const r of rows) groups.set(r.group_id, [...(groups.get(r.group_id) ?? []), r])

  return (
    <main className="space-y-4">
      <h1 className="text-2xl font-bold">Historial</h1>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((f) => (
          <Link
            key={f.key}
            href={`/historial?tipo=${f.key}`}
            className={`whitespace-nowrap rounded-full border px-3 py-1.5 text-xs ${
              f.key === filter.key ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-300 bg-white'
            }`}
          >
            {f.label}
          </Link>
        ))}
      </div>

      {groups.size === 0 && <p className="text-sm text-slate-500">No hay movimientos todavía.</p>}

      <ul className="space-y-2">
        {[...groups.entries()].map(([groupId, g]) => {
          const d = describe(g)
          const detail =
            g[0].kind === 'income'
              ? g.map((r) => `${r.pocket?.emoji ?? ''} ${r.pocket?.name}: ${cop2(r.amount)}`).join(' · ')
              : g[0].pocket
                ? `${g[0].pocket.emoji ?? ''} ${g[0].pocket.name}`
                : ''
          return (
            <li key={groupId} className="rounded-2xl bg-white p-4 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-medium">
                    {d.icon} {d.title}
                  </p>
                  <p className="text-xs text-slate-400">{shortDate(g[0].occurred_on)}</p>
                </div>
                <p className={`font-semibold ${d.tone}`}>{cop2(d.amount)}</p>
              </div>
              {detail && <p className="mt-1 text-xs text-slate-500">{detail}</p>}
              {g[0].note && <p className="mt-1 text-xs italic text-slate-500">“{g[0].note}”</p>}
              <div className="mt-2 text-right">
                <DeleteGroupButton groupId={groupId} />
              </div>
            </li>
          )
        })}
      </ul>
      {rows.length === 200 && <p className="text-center text-xs text-slate-400">Mostrando los últimos 200 registros.</p>}
    </main>
  )
}

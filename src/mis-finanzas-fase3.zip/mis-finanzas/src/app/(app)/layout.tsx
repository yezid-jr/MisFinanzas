import { redirect } from 'next/navigation'
import BottomNav from '@/components/bottom-nav'
import { createClient } from '@/lib/supabase/server'

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient()
  const { data } = await supabase.auth.getClaims()
  if (!data?.claims) redirect('/login')

  return (
    <div className="mx-auto max-w-md px-4 pb-28 pt-6">
      {children}
      <BottomNav />
    </div>
  )
}

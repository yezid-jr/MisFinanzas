import { createClient } from '@/lib/supabase/server'
import { addDays, daysBetween, monthYear } from '@/lib/dates'
import { cop, todayBogota } from '@/lib/format'
import type { PocketBalance } from '@/lib/types'

export default async function GoalsPage() {
  const supabase = await createClient()
  const today = todayBogota()
  const since = addDays(today, -90)

  const [pocketsRes, netRes, firstRes] = await Promise.all([
    supabase.from('pocket_balances').select('*').not('goal', 'is', null).order('priority'),
    supabase.rpc('pocket_net_since', { p_since: since }),
    supabase.from('movements').select('occurred_on').neq('kind', 'opening').order('occurred_on').limit(1),
  ])

  const pockets = (pocketsRes.data ?? []) as PocketBalance[]
  const netByPocket = new Map(
    ((netRes.data ?? []) as { pocket_id: string; net: number }[]).map((r) => [r.pocket_id, Number(r.net)])
  )

  // Ventana de análisis: desde tu primer movimiento (máximo 90 días atrás)
  const firstDate = (firstRes.data?.[0]?.occurred_on as string | undefined) ?? today
  const windowStart = firstDate > since ? firstDate : since
  const windowDays = daysBetween(windowStart, today) + 1
  const enoughData = windowDays >= 14

  return (
    <main className="space-y-4">
      <h1 className="text-2xl font-bold">Metas</h1>
      <p className="text-sm text-slate-500">
        La proyección usa tu ritmo real de ahorro de los últimos {Math.min(windowDays, 90)} días.
      </p>

      {pockets.length === 0 && (
        <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-800">Ninguna caja tiene meta definida.</p>
      )}

      {pockets.map((p) => {
        const goal = Number(p.goal)
        const balance = Number(p.balance)
        const remaining = Math.max(0, goal - balance)
        const perMonth = ((netByPocket.get(p.pocket_id) ?? 0) / windowDays) * 30
        const progress = Math.min(100, Math.max(0, (balance / goal) * 100))

        let projection: string
        if (remaining === 0) projection = '🎉 ¡Meta alcanzada!'
        else if (!enoughData) projection = 'Necesito 2 semanas de movimientos para proyectar.'
        else if (perMonth <= 0) projection = 'Sin avance reciente en esta caja.'
        else {
          const months = remaining / perMonth
          const eta = addDays(today, Math.ceil(months * 30))
          projection = `A este ritmo la alcanzas en ${monthYear(eta)} (≈ ${
            months < 1 ? 'menos de 1 mes' : `${Math.ceil(months)} meses`
          }).`
        }

        return (
          <div key={p.pocket_id} className="space-y-2 rounded-2xl bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between">
              <p className="font-medium">
                {p.emoji} {p.name}
              </p>
              <p className="text-sm font-semibold">{progress.toFixed(1).replace('.', ',')}%</p>
            </div>
            <div className="h-3 overflow-hidden rounded-full bg-slate-100">
              <div className="h-full rounded-full bg-emerald-500" style={{ width: `${progress}%` }} />
            </div>
            <div className="flex justify-between text-xs text-slate-500">
              <span>{cop(balance)}</span>
              <span>Meta {cop(goal)}</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-center text-xs">
              <div className="rounded-lg bg-slate-50 p-2">
                <p className="font-semibold text-slate-700">{cop(remaining)}</p>
                <p className="text-slate-500">Falta</p>
              </div>
              <div className="rounded-lg bg-slate-50 p-2">
                <p className="font-semibold text-slate-700">{enoughData ? cop(Math.max(0, perMonth)) : '—'}</p>
                <p className="text-slate-500">Ritmo por mes</p>
              </div>
            </div>
            <p className="text-sm text-slate-600">{projection}</p>
          </div>
        )
      })}
    </main>
  )
}

import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { loadUpcoming } from '@/lib/data'
import { cop, pct, todayBogota } from '@/lib/format'
import { monthlyRate } from '@/lib/finance'
import UpcomingList from '@/components/upcoming-list'
import { GearIcon } from '@/components/icons'
import type { MonthlySummary, PocketBalance } from '@/lib/types'

const LINKS = [
  { href: '/transferir', label: 'Mover plata', icon: '🔁' },
  { href: '/cobros', label: 'Cobros', icon: '🔔' },
  { href: '/metas', label: 'Metas', icon: '🎯' },
  { href: '/historial', label: 'Historial', icon: '🕘' },
  { href: '/conciliar', label: 'Conciliar', icon: '⚖️' },
]

export default async function HomePage() {
  const supabase = await createClient()
  const firstOfMonth = todayBogota().slice(0, 7) + '-01'

  const [pocketsRes, monthRes, debtsRes, settingsRes, upcoming] = await Promise.all([
    supabase.from('pocket_balances').select('*').order('priority'),
    supabase.from('monthly_summary').select('*').eq('month', firstOfMonth).maybeSingle(),
    supabase.from('debt_balances').select('balance'),
    supabase.from('settings').select('nu_rate_ea').maybeSingle(),
    loadUpcoming(),
  ])

  const pockets = (pocketsRes.data ?? []) as PocketBalance[]
  const month = monthRes.data as MonthlySummary | null
  const total = pockets.reduce((sum, p) => sum + Number(p.balance), 0)
  const totalDebt = (debtsRes.data ?? []).reduce((s, d) => s + Number(d.balance), 0)

  const yieldEa = Number(settingsRes.data?.nu_rate_ea ?? 9.35)
  const yieldBase = pockets.filter((p) => p.earns_yield).reduce((s, p) => s + Number(p.balance), 0)
  const estimatedMonthlyYield = yieldBase * monthlyRate(yieldEa)

  const soon = upcoming.items.filter((i) => i.days <= 14).slice(0, 5)

  return (
    <main className="space-y-6">
      <header className="-mx-4 -mt-6 rounded-b-3xl bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-900 px-5 pb-5 pt-8 text-white shadow-lg">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-slate-300">Total en tus cajas</p>
            <h1 className="mt-1 text-4xl font-bold tracking-tight">{cop(total)}</h1>
          </div>
          <Link href="/ajustes" aria-label="Ajustes" className="rounded-full bg-white/10 p-2.5">
            <GearIcon className="h-5 w-5" />
          </Link>
        </div>

        <div className="mt-5 grid grid-cols-3 gap-2 text-center">
          <HeroStat label="Ingresos" value={month?.income} tone="text-emerald-300" />
          <HeroStat label="Gastos" value={month?.expenses} tone="text-rose-300" />
          <HeroStat label="Rendimiento" value={month?.yield} tone="text-sky-300" />
        </div>

        <p className="mt-3 text-center text-xs text-slate-300">
          Con {pct(yieldEa, 2)} E.A. tus cajas rinden ≈ {cop(estimatedMonthlyYield)} al mes
        </p>
      </header>

      <section className="grid grid-cols-5 gap-2">
        {LINKS.map((l) => (
          <Link
            key={l.href}
            href={l.href}
            className="flex flex-col items-center gap-1 rounded-xl bg-white py-3 text-[11px] text-slate-600 shadow-sm"
          >
            <span className="text-xl">{l.icon}</span>
            {l.label}
          </Link>
        ))}
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Próximos cobros</h2>
          <Link href="/cobros" className="text-xs text-slate-500 underline">
            Ver todos
          </Link>
        </div>
        <UpcomingList items={soon} />
      </section>

      <Link href="/deudas" className="flex items-center justify-between rounded-2xl bg-white p-4 shadow-sm">
        <div>
          <p className="text-sm text-slate-500">Deuda total</p>
          <p className="text-xl font-semibold text-rose-600">{cop(totalDebt)}</p>
        </div>
        <span className="text-sm text-slate-400">Ver detalle →</span>
      </Link>

      <section className="space-y-3">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Mis cajas</h2>
        {pockets.length === 0 && (
          <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-800">
            Aún no hay cajas. Corre el seed.sql en Supabase.
          </p>
        )}
        {pockets.map((p) => (
          <div key={p.pocket_id} className="rounded-2xl bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">
                  {p.emoji} {p.name}
                </p>
                <p className="text-xs text-slate-400">{p.account_name}</p>
              </div>
              <p className="text-lg font-semibold">{cop(p.balance)}</p>
            </div>
            {p.goal && (
              <div className="mt-3">
                <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-emerald-500"
                    style={{ width: `${Math.min(100, Math.max(0, Number(p.goal_pct ?? 0)))}%` }}
                  />
                </div>
                <p className="mt-1 text-xs text-slate-500">
                  {p.goal_pct ?? 0}% de {cop(p.goal)}
                </p>
              </div>
            )}
          </div>
        ))}
      </section>
    </main>
  )
}

function HeroStat({ label, value, tone }: { label: string; value?: number; tone: string }) {
  return (
    <div className="rounded-xl bg-white/10 p-3 backdrop-blur-sm">
      <p className={`text-sm font-semibold ${tone}`}>{cop(value)}</p>
      <p className="mt-0.5 text-[11px] leading-tight text-slate-300">{label} del mes</p>
    </div>
  )
}

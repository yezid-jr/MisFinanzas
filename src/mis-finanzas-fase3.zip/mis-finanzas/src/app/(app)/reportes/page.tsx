import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { addDays, monthYear, shiftMonth, shortDate } from '@/lib/dates'
import { cop, todayBogota } from '@/lib/format'
import { ColumnChart, HBars, LineChart } from '@/components/charts'
import type { MonthlySummary } from '@/lib/types'

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ mes?: string }>
}) {
  const { mes } = await searchParams
  const today = todayBogota()
  const month = /^\d{4}-\d{2}$/.test(mes ?? '') ? (mes as string) : today.slice(0, 7)
  const monthStart = `${month}-01`
  const isCurrent = month === today.slice(0, 7)

  const supabase = await createClient()
  const [summaryRes, catsRes, dailyRes] = await Promise.all([
    supabase.from('monthly_summary').select('*').order('month', { ascending: false }).limit(7),
    supabase.from('expenses_by_category').select('*').eq('month', monthStart).order('total', { ascending: false }),
    supabase.from('daily_totals').select('*').order('occurred_on'),
  ])

  const summary = (summaryRes.data ?? []) as MonthlySummary[]
  const current = summary.find((m) => m.month === monthStart)
  const income = Number(current?.income ?? 0)
  const expenses = Number(current?.expenses ?? 0)
  const debtPayments = Number(current?.debt_payments ?? 0)
  const yieldAmount = Number(current?.yield ?? 0)
  const saved = income + yieldAmount - expenses - debtPayments

  const categories = ((catsRes.data ?? []) as { category: string; total: number }[]).map((c) => ({
    label: c.category,
    value: Number(c.total),
  }))

  const chartMonths = [...summary]
    .reverse()
    .slice(-6)
    .map((m) => ({
      label: new Date(m.month + 'T00:00:00Z').toLocaleDateString('es-CO', { month: 'short', timeZone: 'UTC' }),
      a: Number(m.income),
      b: Number(m.expenses),
    }))

  // Evolución del total en cajas (acumulado) durante los últimos 90 días
  let cumulative = 0
  const points: { label: string; value: number }[] = []
  const since = addDays(today, -90)
  for (const row of (dailyRes.data ?? []) as { occurred_on: string; net: number }[]) {
    cumulative += Number(row.net)
    if (row.occurred_on >= since) points.push({ label: shortDate(row.occurred_on), value: cumulative })
  }

  return (
    <main className="space-y-6">
      <h1 className="text-2xl font-bold">Reportes</h1>

      <div className="flex items-center justify-between rounded-xl bg-white p-2 shadow-sm">
        <Link href={`/reportes?mes=${shiftMonth(month, -1)}`} className="px-3 py-1 text-lg">
          ‹
        </Link>
        <span className="font-medium capitalize">{monthYear(monthStart)}</span>
        {isCurrent ? (
          <span className="px-3 py-1 text-lg text-slate-300">›</span>
        ) : (
          <Link href={`/reportes?mes=${shiftMonth(month, 1)}`} className="px-3 py-1 text-lg">
            ›
          </Link>
        )}
      </div>

      <section className="grid grid-cols-2 gap-2 text-center">
        <Card label="Ingresos" value={cop(income)} tone="text-emerald-600" />
        <Card label="Gastos" value={cop(expenses)} tone="text-rose-600" />
        <Card label="Pagos de deuda" value={cop(debtPayments)} tone="text-orange-600" />
        <Card label="Rendimiento" value={cop(yieldAmount)} tone="text-sky-600" />
      </section>

      <section className="rounded-2xl bg-white p-4 text-center shadow-sm">
        <p className={`text-2xl font-bold ${saved >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>{cop(saved)}</p>
        <p className="text-xs text-slate-500">Ahorro neto del mes (ingresos + rendimiento − gastos − deudas)</p>
      </section>

      <section className="space-y-3 rounded-2xl bg-white p-4 shadow-sm">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Gastos por categoría</h2>
        {categories.length > 0 ? (
          <HBars items={categories} />
        ) : (
          <p className="text-sm text-slate-500">No hay gastos registrados en este mes.</p>
        )}
      </section>

      <section className="space-y-3 rounded-2xl bg-white p-4 shadow-sm">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Ingresos vs gastos</h2>
        {chartMonths.length > 0 ? (
          <ColumnChart data={chartMonths} />
        ) : (
          <p className="text-sm text-slate-500">Aún no hay meses para comparar.</p>
        )}
      </section>

      <section className="space-y-3 rounded-2xl bg-white p-4 shadow-sm">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
          Evolución de tu plata (90 días)
        </h2>
        <LineChart points={points} />
      </section>
    </main>
  )
}

function Card({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="rounded-xl bg-white p-3 shadow-sm">
      <p className={`text-lg font-semibold ${tone}`}>{value}</p>
      <p className="text-[11px] text-slate-500">{label}</p>
    </div>
  )
}

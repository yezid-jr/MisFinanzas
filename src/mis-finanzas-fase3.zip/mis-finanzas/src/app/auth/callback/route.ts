import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get('code')
  const nextParam = searchParams.get('next') ?? '/'
  const next = nextParam.startsWith('/') ? nextParam : '/' // evita redirecciones abiertas

  if (code) {
    const supabase = await createClient()
    const { error } = await supabase.auth.exchangeCodeForSession(code)
    if (!error) {
      const forwardedHost = request.headers.get('x-forwarded-host') // detrás del proxy de Vercel
      const isLocal = process.env.NODE_ENV === 'development'
      if (isLocal || !forwardedHost) return NextResponse.redirect(`${origin}${next}`)
      return NextResponse.redirect(`https://${forwardedHost}${next}`)
    }
  }
  return NextResponse.redirect(`${origin}/login?error=auth`)
}

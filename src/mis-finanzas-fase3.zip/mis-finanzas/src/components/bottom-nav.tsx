'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { CardIcon, ChartIcon, ExpenseIcon, HomeIcon, IncomeIcon } from '@/components/icons'

const items = [
  { href: '/', label: 'Inicio', Icon: HomeIcon },
  { href: '/ingreso', label: 'Ingreso', Icon: IncomeIcon },
  { href: '/gasto', label: 'Gasto', Icon: ExpenseIcon },
  { href: '/deudas', label: 'Deudas', Icon: CardIcon },
  { href: '/reportes', label: 'Reportes', Icon: ChartIcon },
]

export default function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed inset-x-0 bottom-0 z-10 border-t border-slate-200/80 bg-white/90 pb-[env(safe-area-inset-bottom)] backdrop-blur">
      <ul className="mx-auto flex max-w-md px-2 py-1.5">
        {items.map(({ href, label, Icon }) => {
          const active = href === '/' ? pathname === '/' : pathname.startsWith(href)
          return (
            <li key={href} className="flex-1">
              <Link href={href} className="flex flex-col items-center gap-0.5 py-1 text-[11px]">
                <span
                  className={`flex h-8 w-14 items-center justify-center rounded-full transition-colors ${
                    active ? 'bg-slate-900 text-white' : 'text-slate-500'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                </span>
                <span className={active ? 'font-semibold text-slate-900' : 'text-slate-500'}>{label}</span>
              </Link>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}

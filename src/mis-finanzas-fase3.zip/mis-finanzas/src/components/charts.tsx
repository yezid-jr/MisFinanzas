import { cop } from '@/lib/format'

/** Barras horizontales (gastos por categoría) */
export function HBars({
  items,
  color = 'bg-rose-500',
}: {
  items: { label: string; value: number }[]
  color?: string
}) {
  const max = Math.max(1, ...items.map((i) => i.value))
  const total = items.reduce((s, i) => s + i.value, 0) || 1
  return (
    <ul className="space-y-3">
      {items.map((i) => (
        <li key={i.label}>
          <div className="flex justify-between text-sm">
            <span>{i.label}</span>
            <span className="font-medium">
              {cop(i.value)} <span className="text-slate-400">· {Math.round((i.value / total) * 100)}%</span>
            </span>
          </div>
          <div className="mt-1 h-2 rounded-full bg-slate-100">
            <div className={`h-full rounded-full ${color}`} style={{ width: `${(i.value / max) * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  )
}

/** Dos columnas por mes: ingresos (a) contra gastos (b) */
export function ColumnChart({ data }: { data: { label: string; a: number; b: number }[] }) {
  const max = Math.max(1, ...data.flatMap((d) => [d.a, d.b]))
  return (
    <div>
      <div className="flex h-36 items-end gap-3">
        {data.map((d) => (
          <div key={d.label} className="flex h-full flex-1 items-end justify-center gap-1">
            <div
              className="w-3 rounded-t bg-emerald-500"
              style={{ height: `${(d.a / max) * 100}%` }}
              title={`Ingresos ${cop(d.a)}`}
            />
            <div
              className="w-3 rounded-t bg-rose-500"
              style={{ height: `${(d.b / max) * 100}%` }}
              title={`Gastos ${cop(d.b)}`}
            />
          </div>
        ))}
      </div>
      <div className="mt-1 flex gap-3">
        {data.map((d) => (
          <span key={d.label} className="flex-1 text-center text-[11px] capitalize text-slate-500">
            {d.label}
          </span>
        ))}
      </div>
      <div className="mt-3 flex justify-center gap-4 text-xs text-slate-500">
        <span>🟩 Ingresos</span>
        <span>🟥 Gastos</span>
      </div>
    </div>
  )
}

/** Línea de evolución con área */
export function LineChart({ points }: { points: { label: string; value: number }[] }) {
  if (points.length < 2) {
    return <p className="text-sm text-slate-500">Aún no hay suficientes datos para esta gráfica.</p>
  }
  const W = 300
  const H = 120
  const P = 6
  const values = points.map((p) => p.value)
  const min = Math.min(...values)
  const max = Math.max(...values)
  const span = max - min || 1
  const x = (i: number) => P + (i / (points.length - 1)) * (W - 2 * P)
  const y = (v: number) => H - P - ((v - min) / span) * (H - 2 * P)
  const line = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`)
    .join(' ')
  const area = `${line} L${x(points.length - 1).toFixed(1)},${H - P} L${x(0).toFixed(1)},${H - P} Z`

  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
        <path d={area} className="fill-emerald-100" />
        <path d={line} fill="none" className="stroke-emerald-600" strokeWidth={2} />
      </svg>
      <div className="flex justify-between text-[11px] text-slate-500">
        <span>{points[0].label}</span>
        <span className="font-medium text-slate-700">{cop(points[points.length - 1].value)}</span>
      </div>
    </div>
  )
}

'use client'

import { useState, useTransition } from 'react'
import { createRecurring, deleteRecurring, payRecurring } from '@/lib/actions'
import { cop, parsePesos } from '@/lib/format'
import type { Category, PocketLite } from '@/lib/types'
import { Feedback, Field, SubmitButton, inputClass } from '@/components/ui'

export function PayRecurringButton({ id, due, amount }: { id: string; due: string; amount: number }) {
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  return (
    <div className="mt-2">
      <button
        disabled={pending}
        onClick={() =>
          startTransition(async () => {
            const res = await payRecurring({ id, due })
            setError(res.ok ? null : res.error)
          })
        }
        className="rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white disabled:opacity-50"
      >
        {pending ? 'Registrando…' : `Registrar cobro de ${cop(amount)}`}
      </button>
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  )
}

export function DeleteRecurringButton({ id, name }: { id: string; name: string }) {
  const [pending, startTransition] = useTransition()
  return (
    <button
      disabled={pending}
      onClick={() => {
        if (!confirm(`¿Eliminar el cobro "${name}"?`)) return
        startTransition(async () => {
          await deleteRecurring(id)
        })
      }}
      className="text-xs text-slate-400 underline disabled:opacity-50"
    >
      Eliminar
    </button>
  )
}

export function RecurringForm({
  pockets,
  categories,
}: {
  pockets: PocketLite[]
  categories: Category[]
}) {
  const [name, setName] = useState('')
  const [amountText, setAmountText] = useState('')
  const [day, setDay] = useState('')
  const [pocketId, setPocketId] = useState('')
  const [categoryId, setCategoryId] = useState('')
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null)
  const [pending, startTransition] = useTransition()

  const amount = parsePesos(amountText)

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    startTransition(async () => {
      const res = await createRecurring({
        name,
        amount,
        dayOfMonth: Number(day),
        pocketId,
        categoryId: categoryId || null,
      })
      if (res.ok) {
        setResult({ ok: true, message: 'Cobro agregado ✅' })
        setName('')
        setAmountText('')
        setDay('')
      } else {
        setResult({ ok: false, message: res.error })
      }
    })
  }

  return (
    <form onSubmit={onSubmit} className="space-y-3 rounded-2xl bg-white p-4 shadow-sm">
      <p className="text-sm font-semibold text-slate-600">Agregar cobro fijo</p>
      <Field label="Nombre">
        <input className={inputClass} placeholder="Netflix" value={name} onChange={(e) => setName(e.target.value)} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Monto">
          <input
            inputMode="numeric"
            className={inputClass}
            value={amount ? amount.toLocaleString('es-CO') : ''}
            onChange={(e) => setAmountText(e.target.value)}
          />
        </Field>
        <Field label="Día del mes">
          <input
            inputMode="numeric"
            className={inputClass}
            placeholder="15"
            value={day}
            onChange={(e) => setDay(e.target.value.replace(/\D/g, '').slice(0, 2))}
          />
        </Field>
      </div>
      <Field label="Sale de la caja">
        <select className={inputClass} value={pocketId} onChange={(e) => setPocketId(e.target.value)}>
          <option value="">Elige una caja…</option>
          {pockets.map((p) => (
            <option key={p.pocket_id} value={p.pocket_id}>
              {p.emoji} {p.name}
            </option>
          ))}
        </select>
      </Field>
      <Field label="Categoría">
        <select className={inputClass} value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
          <option value="">Sin categoría</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.emoji} {c.name}
            </option>
          ))}
        </select>
      </Field>
      <Feedback result={result} />
      <SubmitButton pending={pending}>Agregar cobro</SubmitButton>
    </form>
  )
}

import type { ReactNode } from 'react'

function Svg({ children, className = 'h-6 w-6' }: { children: ReactNode; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {children}
    </svg>
  )
}

export const HomeIcon = (p: { className?: string }) => (
  <Svg {...p}>
    <path d="M3 11l9-8 9 8" />
    <path d="M5 10v10h5v-6h4v6h5V10" />
  </Svg>
)

export const IncomeIcon = (p: { className?: string }) => (
  <Svg {...p}>
    <path d="M12 4v14" />
    <path d="M6 12l6 6 6-6" />
  </Svg>
)

export const ExpenseIcon = (p: { className?: string }) => (
  <Svg {...p}>
    <path d="M12 20V6" />
    <path d="M6 12l6-6 6 6" />
  </Svg>
)

export const CardIcon = (p: { className?: string }) => (
  <Svg {...p}>
    <rect x="3" y="5" width="18" height="14" rx="2" />
    <path d="M3 10h18" />
    <path d="M7 15h3" />
  </Svg>
)

export const ChartIcon = (p: { className?: string }) => (
  <Svg {...p}>
    <path d="M5 20V11" />
    <path d="M12 20V4" />
    <path d="M19 20v-6" />
  </Svg>
)

export const GearIcon = (p: { className?: string }) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="3" />
    <path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1" />
  </Svg>
)

import type { ReactNode } from 'react'

export const inputClass =
  'w-full rounded-xl border border-slate-300 bg-white px-3 py-3 text-base outline-none focus:border-slate-900'

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block space-y-1">
      <span className="text-sm font-medium text-slate-600">{label}</span>
      {children}
    </label>
  )
}

export function SubmitButton({ pending, children }: { pending: boolean; children: ReactNode }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="w-full rounded-xl bg-slate-900 px-4 py-3 font-medium text-white disabled:opacity-50"
    >
      {pending ? 'Guardando…' : children}
    </button>
  )
}

export function Feedback({ result }: { result: { ok: boolean; message: string } | null }) {
  if (!result) return null
  return (
    <p
      className={`rounded-lg p-3 text-sm ${
        result.ok ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'
      }`}
    >
      {result.message}
    </p>
  )
}

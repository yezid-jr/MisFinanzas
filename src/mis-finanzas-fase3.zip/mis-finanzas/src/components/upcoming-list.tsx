import Link from 'next/link'
import { cop } from '@/lib/format'
import { relativeLabel, shortDate } from '@/lib/dates'
import type { UpcomingItem } from '@/lib/upcoming'
import { PayRecurringButton } from '@/components/cobros-actions'

function tone(days: number) {
  if (days < 0) return 'bg-red-100 text-red-700'
  if (days <= 3) return 'bg-orange-100 text-orange-700'
  if (days <= 7) return 'bg-amber-100 text-amber-700'
  return 'bg-slate-100 text-slate-600'
}

export default function UpcomingList({ items }: { items: UpcomingItem[] }) {
  if (items.length === 0) {
    return <p className="rounded-2xl bg-white p-4 text-sm text-slate-500 shadow-sm">No tienes cobros próximos 🎉</p>
  }

  return (
    <ul className="space-y-2">
      {items.map((it) => (
        <li key={it.key} className="rounded-2xl bg-white p-4 shadow-sm">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate font-medium">{it.title}</p>
              <p className="mt-0.5 flex items-center gap-2 text-xs text-slate-500">
                <span>{shortDate(it.due)}</span>
                <span className={`rounded-full px-2 py-0.5 font-medium ${tone(it.days)}`}>
                  {relativeLabel(it.days)}
                </span>
              </p>
            </div>
            <p className="font-semibold">{cop(it.amount)}</p>
          </div>

          {it.short > 0 && (
            <p className="mt-2 rounded-lg bg-amber-50 p-2 text-xs text-amber-800">
              ⚠️ {it.pocketName} tiene {cop(it.pocketBalance)} y faltan {cop(it.short)}.{' '}
              <Link href="/transferir" className="font-semibold underline">
                Mover plata
              </Link>
            </p>
          )}

          {it.kind === 'recurring' ? (
            <PayRecurringButton id={it.refId} due={it.due} amount={it.amount} />
          ) : (
            <Link href="/deudas" className="mt-2 inline-block text-xs font-medium text-slate-700 underline">
              Ir a pagar →
            </Link>
          )}
        </li>
      ))}
    </ul>
  )
}

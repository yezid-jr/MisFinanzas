'use server'

import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'
import { prevOccurrence } from '@/lib/dates'
import { todayBogota } from '@/lib/format'
import type { IncomeSource } from '@/lib/types'

export type ActionResult = { ok: true } | { ok: false; error: string }

function friendly(message: string) {
  if (message.includes('SALDO_INSUFICIENTE')) {
    return 'Esa caja no tiene saldo suficiente. Haz primero una transferencia desde otra caja.'
  }
  return message
}

const valid = (n: number) => Number.isFinite(n) && n > 0
const done = (): ActionResult => {
  revalidatePath('/', 'layout')
  return { ok: true }
}

// ---------------------------------------------------------------- INGRESOS Y GASTOS

export async function registerIncome(input: {
  amount: number
  source: IncomeSource
  date: string
  note?: string
}): Promise<ActionResult> {
  if (!valid(input.amount)) return { ok: false, error: 'Monto inválido' }
  const supabase = await createClient()
  const { error } = await supabase.rpc('register_weekly_income', {
    p_amount: input.amount,
    p_source: input.source,
    p_date: input.date,
    p_note: input.note || null,
  })
  if (error) return { ok: false, error: friendly(error.message) }
  return done()
}

export async function registerExpense(input: {
  amount: number
  pocketId: string
  categoryId: string | null
  date: string
  note?: string
}): Promise<ActionResult> {
  if (!valid(input.amount)) return { ok: false, error: 'Monto inválido' }
  if (!input.pocketId) return { ok: false, error: 'Elige una caja' }
  const supabase = await createClient()
  const { error } = await supabase.from('movements').insert({
    kind: 'expense',
    pocket_id: input.pocketId,
    amount: -input.amount, // los gastos se guardan en negativo
    category_id: input.categoryId || null,
    occurred_on: input.date,
    note: input.note || null,
  })
  if (error) return { ok: false, error: friendly(error.message) }
  return done()
}

export async function transferBetweenPockets(input: {
  fromId: string
  toId: string
  amount: number
  date: string
  note?: string
}): Promise<ActionResult> {
  if (!valid(input.amount)) return { ok: false, error: 'Monto inválido' }
  if (!input.fromId || !input.toId) return { ok: false, error: 'Elige origen y destino' }
  if (input.fromId === input.toId) return { ok: false, error: 'Origen y destino deben ser distintos' }
  const supabase = await createClient()
  const { error } = await supabase.rpc('transfer_between_pockets', {
    p_from: input.fromId,
    p_to: input.toId,
    p_amount: input.amount,
    p_date: input.date,
    p_note: input.note || null,
  })
  if (error) return { ok: false, error: friendly(error.message) }
  return done()
}

// ---------------------------------------------------------------- DEUDAS

export async function payDebt(input: {
  debtId: string
  pocketId: string
  amount: number
  date: string
  installmentId?: string | null
  note?: string
}): Promise<ActionResult> {
  if (!valid(input.amount)) return { ok: false, error: 'Monto inválido' }
  if (!input.pocketId) return { ok: false, error: 'Elige de qué caja sale el pago' }
  const supabase = await createClient()
  const { error } = await supabase.rpc('pay_debt', {
    p_debt: input.debtId,
    p_pocket: input.pocketId,
    p_amount: input.amount,
    p_date: input.date,
    p_note: input.note || null,
  })
  if (error) return { ok: false, error: friendly(error.message) }
  if (input.installmentId) {
    await supabase.from('debt_installments').update({ paid_at: input.date }).eq('id', input.installmentId)
  }
  return done()
}

/** Compras, intereses o cuotas de manejo: suben la deuda */
export async function addDebtEntry(input: {
  debtId: string
  kind: 'charge' | 'interest' | 'fee'
  amount: number
  date: string
  note?: string
}): Promise<ActionResult> {
  if (!valid(input.amount)) return { ok: false, error: 'Monto inválido' }
  const supabase = await createClient()
  const { error } = await supabase.from('debt_entries').insert({
    debt_id: input.debtId,
    kind: input.kind,
    amount: input.amount,
    occurred_on: input.date,
    note: input.note || null,
  })
  if (error) return { ok: false, error: error.message }
  return done()
}

/** Iguala el saldo de la deuda al valor real que muestra la plataforma */
export async function syncDebtBalance(input: {
  debtId: string
  realBalance: number
  date: string
}): Promise<ActionResult> {
  if (!Number.isFinite(input.realBalance) || input.realBalance < 0) {
    return { ok: false, error: 'Saldo inválido' }
  }
  const supabase = await createClient()
  const { data, error: readError } = await supabase
    .from('debt_balances')
    .select('balance')
    .eq('debt_id', input.debtId)
    .single()
  if (readError) return { ok: false, error: readError.message }

  const diff = Math.round((input.realBalance - Number(data.balance)) * 100) / 100
  if (diff === 0) return done()

  const { error } = await supabase.from('debt_entries').insert({
    debt_id: input.debtId,
    kind: 'adjustment',
    amount: diff,
    occurred_on: input.date,
    note: 'Ajuste al saldo real de la plataforma',
  })
  if (error) return { ok: false, error: error.message }
  return done()
}

// ---------------------------------------------------------------- COBROS RECURRENTES

export async function payRecurring(input: { id: string; due: string }): Promise<ActionResult> {
  const supabase = await createClient()
  const { data: charge, error: readError } = await supabase
    .from('recurring_charges')
    .select('name,amount,pocket_id,category_id')
    .eq('id', input.id)
    .single()
  if (readError) return { ok: false, error: readError.message }

  const { error } = await supabase.from('movements').insert({
    kind: 'expense',
    pocket_id: charge.pocket_id,
    amount: -Number(charge.amount),
    category_id: charge.category_id,
    occurred_on: input.due,
    note: charge.name,
  })
  if (error) return { ok: false, error: friendly(error.message) }

  await supabase.from('recurring_charges').update({ last_posted_on: input.due }).eq('id', input.id)
  return done()
}

export async function createRecurring(input: {
  name: string
  amount: number
  dayOfMonth: number
  pocketId: string
  categoryId: string | null
}): Promise<ActionResult> {
  if (!input.name.trim()) return { ok: false, error: 'Ponle un nombre' }
  if (!valid(input.amount)) return { ok: false, error: 'Monto inválido' }
  if (!(input.dayOfMonth >= 1 && input.dayOfMonth <= 31)) return { ok: false, error: 'Día inválido (1 a 31)' }
  if (!input.pocketId) return { ok: false, error: 'Elige la caja de donde sale' }

  const supabase = await createClient()
  const { error } = await supabase.from('recurring_charges').insert({
    name: input.name.trim(),
    amount: input.amount,
    day_of_month: input.dayOfMonth,
    pocket_id: input.pocketId,
    category_id: input.categoryId || null,
    // así el próximo cobro es el que viene, no uno ya pasado de este mes
    last_posted_on: prevOccurrence(input.dayOfMonth, todayBogota()),
  })
  if (error) return { ok: false, error: error.message }
  return done()
}

export async function deleteRecurring(id: string): Promise<ActionResult> {
  const supabase = await createClient()
  const { error } = await supabase.from('recurring_charges').delete().eq('id', id)
  if (error) return { ok: false, error: error.message }
  return done()
}

// ---------------------------------------------------------------- CONCILIACIÓN Y DESHACER

export async function reconcilePockets(input: {
  items: { pocketId: string; real: number }[]
  date: string
}): Promise<ActionResult> {
  const supabase = await createClient()
  for (const it of input.items) {
    const { error } = await supabase.rpc('reconcile_pocket', {
      p_pocket: it.pocketId,
      p_real: it.real,
      p_date: input.date,
    })
    if (error) return { ok: false, error: friendly(error.message) }
  }
  return done()
}

/** Borra un movimiento completo (todas las filas de su grupo) */
export async function deleteMovementGroup(groupId: string): Promise<ActionResult> {
  const supabase = await createClient()
  const { error: e1 } = await supabase.from('debt_entries').delete().eq('group_id', groupId)
  if (e1) return { ok: false, error: e1.message }
  const { error: e2 } = await supabase.from('movements').delete().eq('group_id', groupId)
  if (e2) return { ok: false, error: e2.message }
  return done()
}
